import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import Home from '../Pages/Home';
import Input from '../Pages/Input';

const Stack = createStackNavigator();

const routes = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Daftar Produk" component={Home} />
      <Stack.Screen name="Input" component={Input} />
    </Stack.Navigator>
  )
}

export default routes;