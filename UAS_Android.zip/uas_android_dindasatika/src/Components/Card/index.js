import React from 'react'
import { StyleSheet, Text, View, Button, Image } from 'react-native'

export const Card = ({  nama, qty, harga , gambar , onEdit, onDelete }) => {
  return (
    <View style={styles.container}>
      <Image source={{uri: gambar}} style={styles.image} />
      <View>
        <Text style={{fontSize:18, fontWeight: 'bold'}}>{nama}</Text>
        <Text>  Qty : {qty}</Text>
        <Text>Harga: {harga}</Text>
      </View>
      <View style={styles.action}>
        <Button title="Edit" color="green" onPress={onEdit} />
        <Button title="Delete" color="red" onPress={onDelete} />
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: 'white',
    marginVertical: 8,
    borderRadius: 4,
    elevation: 2
  },
  action: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8
  },
  image:{
    width:100,
    height:100
  }
})
