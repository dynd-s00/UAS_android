import React from 'react'
import { StyleSheet, Text, View, TextInput } from 'react-native'

export const TextForm = ({ label, onChangeText, defaultValue }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}</Text>
      <TextInput 
        placeholder="Input here.."
        defaultValue={defaultValue}
        style={styles.input}
        onChangeText={(e) => onChangeText(e)}
      />
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 16
  },
  input: {
    borderBottomWidth: 1,
    borderColor: 'black',
    padding: 0,
    paddingVertical: 8
  },
  label: {
    marginBottom: -4
  }
})
