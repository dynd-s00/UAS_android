import React from 'react'
import { StyleSheet, Text, View, TouchableOpacity } from 'react-native'

export const FloatingButton = ({ onPress }) => {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <Text style={styles.label}>+</Text>
    </TouchableOpacity>
  )
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'skyblue',
    width: 50,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 50,
    elevation: 5,
    position: 'absolute',
    bottom: 16,
    right: 16
  },
  label: {
    fontSize: 44,
    color: 'white'
  }
})
