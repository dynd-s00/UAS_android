import axios from 'axios';
import React, { useState, useEffect } from 'react'
import { StyleSheet, Text, View, ScrollView, Dimensions } from 'react-native'
import { Card, FloatingButton } from '../../Components';

export const API_HOST = 'http://192.168.43.178/api-mahasiswa';

const Home = ({ navigation }) => {

  const [data, setData] = useState([]);

  const getDataAPI = () => {
    axios.get(`${API_HOST}/routes/mahasiswa.php`)
    .then(result => {
      setData(result.data);
    })
    .catch(error => {
      console.log(error);
    })
  }

  const onEdit = (data) => {
    navigation.navigate('Input', { data });
  }

  const onDelete = (data) => {
    axios.delete(`${API_HOST}/routes/mahasiswa.php?id=${data.id}&gambar=${data.gambar}`)
    .then(result => {
      getDataAPI();
    })
    .catch(error => {
      console.log(error);
    })
  }

  useEffect(() => {
    navigation.addListener('focus', () => {
      getDataAPI();
    })
  }, []);

  return (
    <ScrollView>
      <View style={styles.container}>
        {
          data.map(data => data ? (
            <Card 
              key={data.id}
              nama={data.nama}
              qty={data.qty}
              harga={data.harga}
              gambar={`${API_HOST}/public/${data.gambar}`}
              onEdit={() => onEdit(data)}
              onDelete={() => onDelete(data)}
            />
          ) : null)
        }
        <FloatingButton onPress={() => navigation.navigate('Input')} />
      </View>
    </ScrollView>
  )
}

export default Home

const styles = StyleSheet.create({
  container: {
    padding: 16,
    minHeight: Dimensions.get('window').height - 100,
  }
})
