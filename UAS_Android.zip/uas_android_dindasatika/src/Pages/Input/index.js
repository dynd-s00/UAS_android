import axios from 'axios';
import React, { useState, useEffect } from 'react'
import { StyleSheet, Text, View, Button, Alert, TouchableOpacity, Image } from 'react-native'
import { launchImageLibrary } from 'react-native-image-picker';
import { TextForm } from '../../Components';
import { API_HOST } from '../Home';

const initialState = {
  nama: '',
  qty: '',
  harga: '',
  gambar:null,
}

const Input = ({ route }) => {

  const params = route.params;

  const [isUpdate, setIsUpdate] = useState(false);
  const [data, setData] = useState(initialState)

  const openImageLibrary = () => {
    const options ={
      mediaType: 'photo',
    }
  

  launchImageLibrary(options, response => {
    if(!response.didCancel) {
      const gambar = {
        uri: response.assets[0].uri,
        type: response.assets[0].type,
        name:response.assets[0].fileName,
      }

      setData({...data, gambar: gambar});
    } else {
      console.log('Did cancle');
    }
  })
  }

  const onSubmit = () => {
    const fd = new FormData();
    Object.keys(data).map(key => {
      fd.append(key, data[key]);
    });
    axios.post(`${API_HOST}/routes/mahasiswa.php`, fd)
    .then(result => {
      Alert.alert('Data posted');
    })
    .catch(error => {
      console.log(error)
    });
  }
 
  const onEdit = () => {
    const fd = new FormData();
    Object.keys(data).map(key=> {
      fd.append(key, data[key]);
    });
    axios.post(`${API_HOST}/routes/mahasiswa.php`, fd)
    .then(result => {
      Alert.alert('Data updated');
      setIsUpdate(false);
      setData(initialState)
    })
    .catch(error => {
      console.log(error)
    });
  }

  useEffect(() => {
    if(params?.data) {
      setIsUpdate(true);
      setData(params.data);
    }
  }, [params?.data]);

  return (
    <View style={styles.container}>
      <View>
        {data.gambar && (
          <Image 
          style={styles.image}
          source={{uri: typeof data.gambar === 'string' ? `${API_HOST}/public/${data.gambar}` : data.gambar.uri}} 
       />
          )}
          <TouchableOpacity style={styles.btnImage} onPress={openImageLibrary}>
            <Text>Upload Gambar</Text>
          </TouchableOpacity>
      </View>
        <TextForm 
          label="Nama Produk"
          defaultValue={data.nama}
          onChangeText={(e) => setData({...data, nama: e})}
        /> 
      <TextForm 
        label="Qty"
        defaultValue={data.qty.toString()}
        onChangeText={(e) => setData({...data, qty: e ? parseInt(e) :0 })}
      />
      <TextForm 
        label="Harga"
        defaultValue={data.harga.toString()}
        onChangeText={(e) => setData({...data, harga: e ? parseInt(e) :0 })}
      />
      <Button title="Submit" onPress={isUpdate ? onEdit : onSubmit} />
    </View>
  )
}

export default Input

const styles = StyleSheet.create({
  container: {
    padding: 16
  },
  btnImage: {
    padding: 8,
    backgroundColor: '#ffff',
    marginBottom: 8,
    width: 150,
    elevation: 5
  },
  image: {
    width: 100,
    height: 100,
    marginBottom: 8,
  }
})
