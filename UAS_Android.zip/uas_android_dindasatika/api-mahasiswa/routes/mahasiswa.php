<?php
require '../cors.php';
require '../controllers/mahasiswa.php';

$post_data = file_get_contents("php://input");
$data = json_decode($post_data);

switch ($method) {
    case 'POST':
        post();
        break;
    case 'GET':
        get();
        break;
    case 'DELETE':
        delete();
        break;
}
