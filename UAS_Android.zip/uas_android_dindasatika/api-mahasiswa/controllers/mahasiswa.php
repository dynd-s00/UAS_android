<?php
require '../config.php';

function post(){
    global $db;
    $random_str = bin2hex(random_bytes(5));

    $nama = $_POST['nama'];
    $qty = $_POST['qty'];
    $harga = $_POST['harga'];

    if(isset($_POST['id'])) {
      put();
    } else {
        $gambar = $random_str.'-'.$_FILES['gambar']['name'];
        $sql = "INSERT INTO produk VALUES('$random_str', '$nama', $qty, $harga, '$gambar')";
        pg_query($db,$sql);
        move_uploaded_file($_FILES['gambar']['tmp_name'], '../public/'.$gambar);
    }
}

function get() {
    global $db;

    $sql = "SELECT * FROM produk ORDER BY nama ASC";
    $ret = pg_query($db, $sql);

    $i = 0;

    while($row = pg_fetch_row($ret)) {
        $data[$i]['id'] = $row[0];
        $data[$i]['nama'] = $row[1];
        $data[$i]['qty'] = $row[2];
        $data[$i]['harga'] = $row[3];
        $data[$i]['gambar'] = $row[4];
        $i++;
    } 
    echo json_encode($data);
}

function put(){
    global $db;

    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $qty = $_POST['qty'];
    $harga = $_POST['harga'];

    if(isset($_FILES['gambar'])) {
        //search recent img file 
        $sql = "SELECT gambar FROM produk WHERE id='$id' ";
        $ret = pg_query($db, $sql);
        while($row = pg_fetch_row($ret)){
            $prev_gambar = $row[0];
        }
        //Delete img file
        unlink('../public/'.$prev_gambar);
        //Rename new file image and upload
        $gambar = $id.'_'.$_FILES["gambar"]["name"];
        move_uploaded_file($_FILES["gambar"]["tmp_name"], "../public/". $gambar);
    } else {
        $gambar = $_POST['gambar'];
    }
    
    $sql ="UPDATE produk SET nama = '$nama', qty = $qty, harga = $harga, gambar = '$gambar' WHERE id = '$id'";
    pg_query($db, $sql);

}

function delete(){
    global $db;

    $id = $_GET['id'];
    $gambar = $_GET['gambar'];

    $sql ="DELETE FROM produk WHERE id = '$id'";
    pg_query($db, $sql);
    unlink('../public/'.$gambar);

}