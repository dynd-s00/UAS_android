<?php
$method = $_SERVER['REQUEST_METHOD'];

if (isset($_SERVER['HTTP_ORIGIN'])){
    header('Access-Control-Allow-Origin: *');
}