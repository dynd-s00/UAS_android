<?php
$host = "host=localhost";
$port = "port=5432";
$dbname = "dbname=produk";
$credentials = "user=postgres password=admin";

$db = pg_connect("$host $port $dbname $credentials");

if (!$db) {
    echo "error : koneksi daatbase Gagal!";
}



?>