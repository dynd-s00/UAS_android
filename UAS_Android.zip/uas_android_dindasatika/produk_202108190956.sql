INSERT INTO produk (id,nama,qty,harga,gambar) VALUES 
('db813e1722','Cocolatos',3,30000,'db813e1722-rn_image_picker_lib_temp_781c81ce-d695-4634-8a7f-f2136ba0bf15.jpg')
,('130e22ad64','Choki choki',6,20000,'130e22ad64-rn_image_picker_lib_temp_2020439d-a184-4d68-b2f7-f9d8b39fdef7.png')
;